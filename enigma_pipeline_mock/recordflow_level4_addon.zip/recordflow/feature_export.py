"""Generate deterministic point-in-time ML features from supplier snapshots.

LEVEL 4: This implementation intentionally contains silent correctness bugs.
Fix this file without changing its public API or the supplied tests.
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Iterable

from .domain import BusinessRecord


@dataclass(frozen=True)
class TrainingExample:
    business_id: str
    label_time: datetime
    city: str | None
    source: str | None
    record_age_hours: float | None


def build_training_examples(
    snapshots: Iterable[BusinessRecord],
    labels: Iterable[tuple[str, datetime]],
) -> list[TrainingExample]:
    """See LEVEL_4.md for the exact as-of join contract."""
    latest = {}
    for r in snapshots:
        if r.business_id not in latest or r.updated_at >= latest[r.business_id].updated_at:
            latest[r.business_id] = r

    result = []
    for business_id, label_time in labels:
        r = latest.get(business_id)
        if r is None:
            result.append(TrainingExample(business_id, label_time, None, None, None))
            continue
        result.append(
            TrainingExample(
                business_id=business_id,
                label_time=label_time,
                city=r.city,
                source=r.source,
                record_age_hours=(label_time - r.updated_at).total_seconds() / 3600,
            )
        )
    return result
